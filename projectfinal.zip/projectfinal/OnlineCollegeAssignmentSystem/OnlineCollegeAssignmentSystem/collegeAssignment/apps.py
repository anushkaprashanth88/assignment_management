from django.apps import AppConfig


class CollegeassignmentConfig(AppConfig):
    name = 'collegeAssignment'
